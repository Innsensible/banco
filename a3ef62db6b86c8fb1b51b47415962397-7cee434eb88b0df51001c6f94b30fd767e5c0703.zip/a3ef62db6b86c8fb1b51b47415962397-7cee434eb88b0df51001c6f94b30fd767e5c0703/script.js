let saldo = 5000;

function transferir(){

let monto = parseInt(
document.getElementById("monto").value
);

if(monto > saldo){

document.getElementById("mensaje")
.innerHTML = "❌ Saldo insuficiente";

document.getElementById("mensaje")
.style.color = "red";

}else{

saldo -= monto;

document.getElementById("saldo")
.innerHTML = "$" + saldo;

document.getElementById("mensaje")
.innerHTML = "✅ Transferencia exitosa";

document.getElementById("mensaje")
.style.color = "green";

}

}